sap.ui.define([
	"sap/ui/core/mvc/Controller",
	"sap/ui/core/format/DateFormat",
	"com/dpzSUPPLERS/model/formatter",
	"sap/m/MessageBox",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"

], function(Controller, DateFormat, formatter, MessageBox, Filter, FilterOperator) {
	"use strict";

	return Controller.extend("com.dpzSUPPLERS.controller.View1suppliers", {

		formatte: formatter,
		onInit: function() {
			this.livechange = true;
			var uriemployee = "/sap/opu/odata/sap/ZEMPLOYEE_DATA01_SRV/";
			// var Uri = "/Northwind/V2/(S(xaiwi1mqzyzu0aak5cvips1d))/OData/OData.svc/";
			this.oModel = new sap.ui.model.odata.ODataModel(uriemployee, true);
			this.getView().setModel(this.oModel, "ODataEmployeeEntity");
			this.getView().setModel(this.oModel, "ODataCompanyEntity");
			var oModel = new sap.ui.model.json.JSONModel({
				name: ""
			});
			// Set the model to the view
			this.getView().setModel(oModel);
			var jsonmodel = new sap.ui.model.json.JSONModel("model/Status.json");
			this.getView().setModel(jsonmodel, "StatusModel");
		},

		onExpandCollapse: function() {
			debugger;
			var oTable = this.getView().byId("myTable");
			var aColumns = oTable.getColumns();

			for (var i = 2; i < aColumns.length; i++) {
				aColumns[i].setVisible(false);

			}
			oTable.setWidth("330px");

			this.getView().byId("simpleform").setVisible(true);
			this.getView().byId("simpleformText").setVisible(true);

			// this.getView().byId("myTable").setVisible(false);

			// } 
		},
		onRowClick: function(oevent) {
			debugger;
			var that = this;

			//     				if(	this.getView().byId("employeeName").getVisible()===false&&
			// this.getView().byId("employeeDepartment").getVisible()===false&&this.getView().byId("employeeMail").getVisible()===false&&
			// this.getView().byId("employeePhone").getVisible()===false&&	this.getView().byId("employeeLocation").getVisible()===false&&
			// 	this.getView().byId("joiningDate").getVisible()===false)
			var object = oevent.getSource().getBindingContext("ODataEmployeeEntity").getObject();
			this.objRowclicked = object;
			var ClickedId = object.Emp_Id;

			if (ClickedId.slice(length - 2) === '10') {
				var id = ClickedId.slice(length - 2);

			} else {
				id = ClickedId.slice(length - 1);

			}
			// "/Products("+Number(IDEdited)+")";
			var employeeSetPath = "/zemployeeSet('" + (id) + "')";
			// var ss=oevent.getSource().getBindingContext("ODataEmployeeEntity").getPath();
			var companyform = this.getView().byId("simpleformTextfields");

			if (this.getView().byId("simpleform").getVisible() === true) {

				if (this.getView().byId("employeeID").getValue() === ""&&this.getView().byId("employeeName").getValue() === "" &&
					this.getView().byId("employeeDepartment").getValue() === "" && this.getView().byId("employeeMail").getValue() === "" &&
					this.getView().byId("employeePhone").getValue() === "" && this.getView().byId("employeeLocation").getValue() === "" &&
					this.getView().byId("joiningDate").getValue() === "")

				{

					var searchfield = this.getView().byId("searchField");
					// this.getView().byId("searchField").setVisible(false);
					// this.oModel
					var model = this.getView().getModel("ODataEmployeeEntity");
					var employeeSetPathExpand = employeeSetPath + "?$expand=to_cc";
					var oTable = this.byId("myTable");

					model.read(employeeSetPathExpand, {

						success: function(result) {
							// console.log(result);
							var company = result.to_cc.results[0];
							if (company === undefined) {

								MessageBox.warning("THE Employee doesnot contain Company Details");
								var table = that.getView().byId("myTable");
								if (table.getWidth() === '100%') {
									that.getView().byId("BackBtn").setVisible(false);

									searchfield = that.getView().byId("searchField");
									that.getView().byId("searchField").setVisible(true);
								} else {
									that.getView().byId("BackBtn").setVisible(true);

									searchfield = that.getView().byId("searchField");
									that.getView().byId("searchField").setVisible(true);
								}

								// MessageBox.Warning("kk");
								//
							} else {
								that.getView().byId("BackBtn").setVisible(true);
								that.getView().byId("title").setVisible(false);

								companyform.setWidth("900px");
								that.getView().byId("simpleformTextfields").setTitle("Company Form");
								that.getView().byId("CompanyNameLabel").setVisible(true);
								that.getView().byId("CompanyLocationLabel").setVisible(true);
								that.getView().byId("companyMailLabel").setVisible(true);
								that.getView().byId("CompanyUrlLabel").setVisible(true);
								that.getView().byId("ContactNoLabel").setVisible(true);

								that.getView().byId("CompanyMailText").setVisible(true);
								that.getView().byId("CompanyUrl").setVisible(true);
								that.getView().byId("companyNameText").setVisible(true);
								that.getView().byId("CompanyLocationText").setVisible(true);
								that.getView().byId("ContactNoText").setVisible(true);

								// Emp_Id employeeidTextEdit

								that.getView().byId("empIDLabel").setVisible(true);
								that.getView().byId("empNameLabel").setVisible(false);
								that.getView().byId("empDepartmentLabel").setVisible(false);
								that.getView().byId("empMailLabel").setVisible(false);
								that.getView().byId("empMobilelabel").setVisible(false);
								that.getView().byId("emploclabel").setVisible(false);
								that.getView().byId("empjoinlabel").setVisible(false);
								that.getView().byId("empstatusLabel").setVisible(false);
								that.getView().byId("empcreatedLabel").setVisible(false);

								// 
								that.getView().byId("employeeidTextEdit").setVisible(true);
								that.getView().byId("employeeNameTextEdit").setVisible(false);
								that.getView().byId("employeeDepartmentTextEdit").setVisible(false);
								that.getView().byId("employeeMailTextEdit").setVisible(false);
								that.getView().byId("employeePhone-noTextEdit").setVisible(false);
								that.getView().byId("employeeLocationTextEdit").setVisible(false);
								that.getView().byId("joiningDateTextEdit").setVisible(false);
								that.getView().byId("StatusTextEdit").setVisible(false);

								that.getView().byId("CreatedByTextEdit").setVisible(false);

								// that.getView().byId("employeeidTextEdit").setText(company.Emp_Id);
								that.getView().byId("companyNameText").setText(company.CompanyName);

								that.getView().byId("CompanyLocationText").setText(company.CompanyLoc);
								that.getView().byId("ContactNoText").setText(company.ContactNo);
								that.getView().byId("CompanyMailText").setText(company.CompanyMail);
								// that.getView().byId("employeePhone-noText").setText();
								// that.getView().byId("CompanyUrlEdit").setText(company.CompanyUrl);
								that.getView().byId("CompanyUrl").setText(company.CompanyUrl);
								that.getView().byId("employeeidTextEdit").setText(object.Emp_Id);

							
								that.onExpandCollapse();
								that.getView().byId("simpleform").setVisible(false);
								oTable.setWidth("330px");
							}
						
						},

						// },
						error: function() {

						}
					});
				} else {
					MessageBox.confirm("Are you sure want to navigate  the Data Will be Lost", {
						onClose: function(Navgiate) {
							if (Navgiate === "OK") {

								// MessageBox.success("Deleted ");

								that.getView().byId("simpleformTextfields").setTitle("Company Form");

								var searchfield = that.getView().byId("searchField");
								that.getView().byId("searchField").setVisible(true);
								// oevent.getSource().getBindingContext("ODataEmployeeEntity").getObject();
								// var ss=oevent.getSource().getBindingContext("ODataEmployeeEntity").getPath();
								// this.oModel
								var model = that.getView().getModel("ODataEmployeeEntity");
								var employeeSetPathExpand = employeeSetPath + "?$expand=to_cc";
								var oTable = that.byId("myTable");

								model.read(employeeSetPathExpand, {

									success: function(result) {
										// console.log(result);
										that.company = result.to_cc.results[0];

										if (that.company === undefined) {
											MessageBox.warning("THE Employee doesnot contain Company Details");
											var table = that.getView().byId("myTable");
											if (table.getWidth() === '100%') {
												that.getView().byId("BackBtn").setVisible(false);

												searchfield = that.getView().byId("searchField");
												that.getView().byId("searchField").setVisible(true);
											} else {
												that.getView().byId("BackBtn").setVisible(true);

												searchfield = that.getView().byId("searchField");
												that.getView().byId("searchField").setVisible(true);
											}

										} else {
											that.getView().byId("title").setVisible(false);

											that.getView().byId("BackBtn").setVisible(true);

											that.getView().byId("simpleformTextfields").setTitle("Company Form");
											companyform.setWidth("900px");

											that.onRowclicking();
										}

									}
								});
								// that.TableTotal();

							} else {

							}

						}

					});

					// }
				}
			} else {
			 searchfield = this.getView().byId("searchField");
				// this.getView().byId("searchField").setVisible(false);
				// this.oModel
				 model = this.getView().getModel("ODataEmployeeEntity");
				 employeeSetPathExpand = employeeSetPath + "?$expand=to_cc";
				 oTable = this.byId("myTable");

				model.read(employeeSetPathExpand, {

					success: function(result) {
						// console.log(result);
						var company = result.to_cc.results[0];
						if (company === undefined) {
							MessageBox.warning("THE Employee doesnot contain Company Details");

							var table = that.getView().byId("myTable");
							if (table.getWidth() === '100%') {
								that.getView().byId("BackBtn").setVisible(false);
								searchfield = that.getView().byId("searchField");
								that.getView().byId("searchField").setVisible(true);
							} else {
								that.getView().byId("BackBtn").setVisible(true);
								searchfield = that.getView().byId("searchField");
								that.getView().byId("searchField").setVisible(true);
							}

							// MessageBox.Warning("kk");
							//
						} else {
							that.getView().byId("title").setVisible(false);

							that.getView().byId("simpleformTextfields").setTitle("Company Form");

							that.getView().byId("BackBtn").setVisible(true);

							companyform.setWidth("900px");

							that.getView().byId("CompanyNameLabel").setVisible(true);
							that.getView().byId("CompanyLocationLabel").setVisible(true);
							that.getView().byId("companyMailLabel").setVisible(true);
							that.getView().byId("CompanyUrlLabel").setVisible(true);
							that.getView().byId("ContactNoLabel").setVisible(true);

							that.getView().byId("CompanyMailText").setVisible(true);
							that.getView().byId("CompanyUrl").setVisible(true);
							that.getView().byId("companyNameText").setVisible(true);
							that.getView().byId("CompanyLocationText").setVisible(true);
							that.getView().byId("ContactNoText").setVisible(true);

							// Emp_Id employeeidTextEdit

							that.getView().byId("empIDLabel").setVisible(true);
							that.getView().byId("empNameLabel").setVisible(false);
							that.getView().byId("empDepartmentLabel").setVisible(false);
							that.getView().byId("empMailLabel").setVisible(false);
							that.getView().byId("empMobilelabel").setVisible(false);
							that.getView().byId("emploclabel").setVisible(false);
							that.getView().byId("empjoinlabel").setVisible(false);
							that.getView().byId("empstatusLabel").setVisible(false);
							that.getView().byId("empcreatedLabel").setVisible(false);

							// 
							that.getView().byId("employeeidTextEdit").setVisible(true);
							that.getView().byId("employeeNameTextEdit").setVisible(false);
							that.getView().byId("employeeDepartmentTextEdit").setVisible(false);
							that.getView().byId("employeeMailTextEdit").setVisible(false);
							that.getView().byId("employeePhone-noTextEdit").setVisible(false);
							that.getView().byId("employeeLocationTextEdit").setVisible(false);
							that.getView().byId("joiningDateTextEdit").setVisible(false);
							that.getView().byId("StatusTextEdit").setVisible(false);

							that.getView().byId("CreatedByTextEdit").setVisible(false);

							// that.getView().byId("employeeidTextEdit").setText(company.Emp_Id);
							that.getView().byId("companyNameText").setText(company.CompanyName);

							that.getView().byId("CompanyLocationText").setText(company.CompanyLoc);
							that.getView().byId("ContactNoText").setText(company.ContactNo);
							that.getView().byId("CompanyMailText").setText(company.CompanyMail);
							// that.getView().byId("employeePhone-noText").setText();
							// that.getView().byId("CompanyUrlEdit").setText(company.CompanyUrl);
							that.getView().byId("CompanyUrl").setText(company.CompanyUrl);
							that.getView().byId("employeeidTextEdit").setText(object.Emp_Id);

							that.onExpandCollapse();
							that.getView().byId("simpleform").setVisible(false);
							oTable.setWidth("330px");
						}

						// },
					},
					error:function(error){
										MessageBox.error(error.response.statusText);

					}
				});

			}
		},
		onEdit: function(oevent) {
			debugger;
			this.livechange = false;
			this.getView().byId("BackBtn").setVisible(true);
			var submitBtn = this.getView().byId("SubmitBtn");
			submitBtn.setText("Save");
			submitBtn.setIcon("sap-icon://save");
			var companyform = this.getView().byId("simpleformTextfields");
			this.getView().byId("title").setVisible(false);

			var searchfield = this.getView().byId("searchField");
			this.getView().byId("searchField").setVisible(true);
			var editObject = oevent.getSource().getBindingContext("ODataEmployeeEntity").getObject();
			this.path = oevent.getSource().getBindingContext("ODataEmployeeEntity").getPath();

			if (editObject.Status === "A")

			{
				this.getView().byId("StatusTextEdit").setText("Approved");
				this.getView().byId("Status").setValue("Approved");

			} else if (editObject.Status === "R") {
				this.getView().byId("StatusTextEdit").setText("Reject");
				this.getView().byId("Status").setValue("Reject");

			} else if (editObject.Status === "P") {

				this.getView().byId("StatusTextEdit").setText("In Progress");
				this.getView().byId("Status").setValue("In Progress");

			}
			this.onExpandCollapse();
			this.editObject = editObject;
			var Datecreate = DateFormat.getDateInstance({
				pattern: "MM.dd.yyyy"
			});
			submitBtn.setText("Save");
								submitBtn.setIcon("sap-icon://save");

			var joinDate = Datecreate.format(editObject.Emply_JDate);
			this.getView().byId("employeeidTextEdit").setText(editObject.Emp_Id);
			companyform.setWidth("410px");
			this.getView().byId("employeeNameTextEdit").setText(editObject.Emp_Name);
			this.getView().byId("employeeDepartmentTextEdit").setText(editObject.Emp_Dept);
			this.getView().byId("employeeMailTextEdit").setText(editObject.Emp_Mail);
			this.getView().byId("employeePhone-noTextEdit").setText(editObject.Emp_PhnNo);
			this.getView().byId("employeeLocationTextEdit").setText(editObject.Emp_Loc);
			this.getView().byId("joiningDateTextEdit").setText(joinDate);
			//this.getView().byId("StatusTextEdit").setText(editObject.Status);
			this.getView().byId("CreatedByTextEdit").setText(editObject.Created_by);

			//
			this.getView().byId("empIDLabel").setVisible(true);
			this.getView().byId("empNameLabel").setVisible(true);
			this.getView().byId("empDepartmentLabel").setVisible(true);
			this.getView().byId("empMailLabel").setVisible(true);
			this.getView().byId("empMobilelabel").setVisible(true);
			this.getView().byId("emploclabel").setVisible(true);
			this.getView().byId("empjoinlabel").setVisible(true);
			this.getView().byId("empstatusLabel").setVisible(true);
			this.getView().byId("empcreatedLabel").setVisible(true);
			//
			this.getView().byId("employeeidTextEdit").setVisible(true);
			this.getView().byId("employeeNameTextEdit").setVisible(true);
			this.getView().byId("employeeDepartmentTextEdit").setVisible(true);
			this.getView().byId("employeeMailTextEdit").setVisible(true);
			this.getView().byId("employeePhone-noTextEdit").setVisible(true);
			this.getView().byId("employeeLocationTextEdit").setVisible(true);
			this.getView().byId("joiningDateTextEdit").setVisible(true);
			this.getView().byId("StatusTextEdit").setVisible(true);
			this.getView().byId("CreatedByTextEdit").setVisible(true);

		
			this.getView().byId("CompanyNameLabel").setVisible(false);
			this.getView().byId("CompanyLocationLabel").setVisible(false);
			this.getView().byId("companyMailLabel").setVisible(false);
			this.getView().byId("CompanyUrlLabel").setVisible(false);
			this.getView().byId("ContactNoLabel").setVisible(false);

			this.getView().byId("CompanyMailText").setVisible(false);
			this.getView().byId("CompanyUrl").setVisible(false);
			this.getView().byId("companyNameText").setVisible(false);
			this.getView().byId("CompanyLocationText").setVisible(false);
			this.getView().byId("ContactNoText").setVisible(false);
this.getView().byId("employeeID").setEditable(false);
			this.getView().byId("employeeID").setValue(editObject.Emp_Id);
			this.getView().byId("employeeName").setValue(editObject.Emp_Name);
			this.getView().byId("employeeDepartment").setValue(editObject.Emp_Dept);
			this.getView().byId("employeeMail").setValue(editObject.Emp_Mail);
			this.getView().byId("employeePhone").setValue(editObject.Emp_PhnNo);
			this.getView().byId("employeeLocation").setValue(editObject.Emp_Loc);
			this.getView().byId("joiningDate").setValue(joinDate);
			//this.getView().byId("Status").setValue(editObject.Status);
			//this.getView().byId("CreatedBy").setVisible(true);
			this.getView().byId("CreatedBy").setValue(editObject.Created_by);

			//this.getView().byId().setText();

		},
		onCreate: function() {
			debugger;
			var that = this;
			var companyform = this.getView().byId("simpleformTextfields");
			companyform.setWidth("410px");
			this.getView().byId("title").setVisible(false);

			var submitBtn = this.getView().byId("SubmitBtn");
			this.getView().byId("BackBtn").setVisible(true);

							 if( this.getView().byId("simpleform").getVisible()===true||	
							 	this.getView().byId("employeeName").getValue() !==""||
							this.getView().byId("employeeDepartment").getValue()!==""||this.getView().byId("employeeMail").getValue()!==""||
							this.getView().byId("employeePhone").getValue()!==""||	this.getView().byId("employeeLocation").getValue()!==""||
								this.getView().byId("joiningDate").getValue()!=="")

			{
				MessageBox.alert("Please Complete pending Operation");
			}

			else{
			this.onExpandCollapse();
			var oTable = this.getView().byId("myTable");
			var aColumns = oTable.getColumns();

			for (var i = 2; i < aColumns.length; i++) {
				aColumns[i].setVisible(false);

			}
			oTable.setWidth("340px");
			// this.livechange=true;
			// this.getView().byId("simpleform").setVisible(true);
			// <Input   id="employeeID" value="{objectModel>/clickedObject/Emp_Id}" editable="false" ></Input>	
			this.getView().byId("employeeID").setEditable(true);

			//                 this.getView().byId("simpleformText").setVisible(true);
			if (this.getView().byId("simpleform").getVisible() === false) {
				this.oncreating();
				companyform.setWidth("410px");

				submitBtn.setText("Create");
					submitBtn.setIcon("sap-icon://create-form");
				this.getView().byId("simpleformTextfields").setTitle("Employee Form");
				this.livechange = true;
				this.inputValueState();
			} else {
				if (this.getView().byId("simpleform").getVisible() === true)

				{
					if (this.getView().byId("employeeName").getValue() === "" &&
						this.getView().byId("employeeDepartment").getValue() === "" && this.getView().byId("employeeMail").getValue() === "" &&
						this.getView().byId("employeePhone").getValue() === "" && this.getView().byId("employeeLocation").getValue() === "" &&
						this.getView().byId("joiningDate").getValue() === "") {
						companyform.setWidth("410px");
						this.oncreating();
						this.getView().byId("title").setVisible(false);

						submitBtn.setText("Create");
											submitBtn.setIcon("sap-icon://create-form");

						this.livechange = true;
						this.inputValueState();
					} else {

						MessageBox.confirm("Are you sure want to navigate data will be lost", {
							onClose: function(deleterecord) {
								if (deleterecord === MessageBox.Action.OK) {
									this.livechange = true;
									companyform.setWidth("410px");
									that.getView().byId("simpleformTextfields").setTitle("Employee Form");
									that.inputValueState();
									submitBtn.setText("Create");
														submitBtn.setIcon("sap-icon://create-form");

									that.getView().byId("CompanyNameLabel").setVisible(false);
									that.getView().byId("CompanyLocationLabel").setVisible(false);
									that.getView().byId("companyMailLabel").setVisible(false);
									that.getView().byId("CompanyUrlLabel").setVisible(false);
									that.getView().byId("ContactNoLabel").setVisible(false);

									that.getView().byId("CompanyMailText").setVisible(false);
									that.getView().byId("CompanyUrl").setVisible(false);
									that.getView().byId("companyNameText").setVisible(false);
									that.getView().byId("CompanyLocationText").setVisible(false);
									that.getView().byId("ContactNoText").setVisible(false);

									that.getView().byId("employeeID").setValue("");
									that.getView().byId("employeeName").setValue("");
									that.getView().byId("employeeDepartment").setValue("");
									that.getView().byId("employeeMail").setValue("");
									that.getView().byId("employeePhone").setValue("");
									that.getView().byId("employeeLocation").setValue("");
									that.getView().byId("joiningDate").setValue("");
									that.getView().byId("Status").setValue("");
									//this.getView().byId("CreatedBy").setVisible(true);
									that.getView().byId("CreatedBy").setValue("");

									that.getView().byId("employeeidTextEdit").setText("");
									that.getView().byId("employeeNameTextEdit").setText("");
									that.getView().byId("employeeDepartmentTextEdit").setText("");
									that.getView().byId("employeeMailTextEdit").setText("");
									that.getView().byId("employeePhone-noTextEdit").setText("");
									that.getView().byId("employeeLocationTextEdit").setText("");
									that.getView().byId("joiningDateTextEdit").setText("");
									that.getView().byId("StatusTextEdit").setText("");
									that.getView().byId("CreatedByTextEdit").setText("");

									//
									//this.getView().byId("CreatedBy").setValue("");

									that.getView().byId("employeeidTextEdit").setVisible(true);
									that.getView().byId("employeeNameTextEdit").setVisible(true);
									that.getView().byId("employeeDepartmentTextEdit").setVisible(true);
									that.getView().byId("employeeMailTextEdit").setVisible(true);
									that.getView().byId("employeePhone-noTextEdit").setVisible(true);
									that.getView().byId("employeeLocationTextEdit").setVisible(true);
									that.getView().byId("joiningDateTextEdit").setVisible(true);
									that.getView().byId("StatusTextEdit").setVisible(true);
									that.getView().byId("CreatedByTextEdit").setVisible(false);
									//
									that.getView().byId("empIDLabel").setVisible(true);
									that.getView().byId("empNameLabel").setVisible(true);
									that.getView().byId("empDepartmentLabel").setVisible(true);
									that.getView().byId("empMailLabel").setVisible(true);
									that.getView().byId("empMobilelabel").setVisible(true);
									that.getView().byId("emploclabel").setVisible(true);
									that.getView().byId("empjoinlabel").setVisible(true);
									that.getView().byId("empstatusLabel").setVisible(true);
									that.getView().byId("empcreatedLabel").setVisible(true);
								}

							}
						});
					}

				} else {
					MessageBox.confirm("Are you sure want to navigate data will be lost", {
						onClose: function(deleterecord) {
							if (deleterecord === MessageBox.Action.OK) {

								this.livechange = true;
								companyform.setWidth("410px");
								submitBtn.setText("Create");
													submitBtn.setIcon("sap-icon://create-form");

								this.getView().byId("simpleformTextfields").setTitle("Employee Form");
								that.inputValueState();
								that.getView().byId("CompanyNameLabel").setVisible(false);
								that.getView().byId("CompanyLocationLabel").setVisible(false);
								that.getView().byId("companyMailLabel").setVisible(false);
								that.getView().byId("CompanyUrlLabel").setVisible(false);
								that.getView().byId("ContactNoLabel").setVisible(false);

								that.getView().byId("CompanyMailText").setVisible(false);
								that.getView().byId("CompanyUrl").setVisible(false);
								that.getView().byId("companyNameText").setVisible(false);
								that.getView().byId("CompanyLocationText").setVisible(false);
								that.getView().byId("ContactNoText").setVisible(false);

								that.getView().byId("employeeID").setValue("");
								that.getView().byId("employeeName").setValue("");
								that.getView().byId("employeeDepartment").setValue("");
								that.getView().byId("employeeMail").setValue("");
								that.getView().byId("employeePhone").setValue("");
								that.getView().byId("employeeLocation").setValue("");
								that.getView().byId("joiningDate").setValue("");
								that.getView().byId("Status").setValue("");
								//this.getView().byId("CreatedBy").setVisible(true);
								that.getView().byId("CreatedBy").setValue("");

								that.getView().byId("employeeidTextEdit").setText("");
								that.getView().byId("employeeNameTextEdit").setText("");
								that.getView().byId("employeeDepartmentTextEdit").setText("");
								that.getView().byId("employeeMailTextEdit").setText("");
								that.getView().byId("employeePhone-noTextEdit").setText("");
								that.getView().byId("employeeLocationTextEdit").setText("");
								that.getView().byId("joiningDateTextEdit").setText("");
								that.getView().byId("StatusTextEdit").setText("");
								that.getView().byId("CreatedByTextEdit").setText("");

								//
								//this.getView().byId("CreatedBy").setValue("");

								that.getView().byId("employeeidTextEdit").setVisible(true);
								that.getView().byId("employeeNameTextEdit").setVisible(true);
								that.getView().byId("employeeDepartmentTextEdit").setVisible(true);
								that.getView().byId("employeeMailTextEdit").setVisible(true);
								that.getView().byId("employeePhone-noTextEdit").setVisible(true);
								that.getView().byId("employeeLocationTextEdit").setVisible(true);
								that.getView().byId("joiningDateTextEdit").setVisible(true);
								that.getView().byId("StatusTextEdit").setVisible(true);
								that.getView().byId("CreatedByTextEdit").setVisible(false);
								//
								that.getView().byId("empIDLabel").setVisible(true);
								that.getView().byId("empNameLabel").setVisible(true);
								that.getView().byId("empDepartmentLabel").setVisible(true);
								that.getView().byId("empMailLabel").setVisible(true);
								that.getView().byId("empMobilelabel").setVisible(true);
								that.getView().byId("emploclabel").setVisible(true);
								that.getView().byId("empjoinlabel").setVisible(true);
								that.getView().byId("empstatusLabel").setVisible(true);
								that.getView().byId("empcreatedLabel").setVisible(true);
							} else {

							}
						}
					});

					// 

				}
			
			}
			}
		},
		onNameChange: function(oEvent) {
			var model = this.getView().getModel("StatusModel");

			var DepartMentEntity = model.getData().Department;
			var validName = /^[a-zA-Z]+(?:\s[a-zA-Z]+)?$/;
			// var validID=/^[a-zA-Z0-9]{10}$/;

			var validateMobileNo = /^[89]\d{9}$/;
			var validmail = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;
			var validID = /^[0-9]{1,4}$/;

			var LocationEntity = model.getData().LocationEntity;

			debugger;
			if (this.livechange === true) {

				var nameValue = oEvent.getParameter("value");
				var ID = oEvent.getSource().getId().split("-")[2];

				if (ID === "employeeName") {
					var textName = this.getView().byId("employeeNameTextEdit");
					if (nameValue.trim().match(validName)) {
						textName.setText(nameValue.trim());

						this.getView().byId("employeeName").setValueState("None");
					} else {
						this.getView().byId("employeeName").setValueState("Error");
						this.getView().byId("employeeName").setValueStateText("Please Enter Name");
						// isValid = false;
					}

				}
			
				else if (ID === "employeeLocation") {
					var textName = this.getView().byId("employeeLocationTextEdit");

					if (nameValue !== "") {
						// this.getView().byId("employeeLocation").setValueState("None");

						for (var i = 0; i < LocationEntity.length; i++) {

							if (LocationEntity[i].text === nameValue.trim()) {
								this.getView().byId("employeeLocation").setValueState("None");
								// isValidComboboxLocation=true;
								textName.setText(nameValue.trim());

								break;
							} else {
								this.getView().byId("employeeLocation").setValueState("Error");
								this.getView().byId("employeeLocation").setValueStateText("Please select correct value");
								// isValidComboboxLocation=false;
							}
						}
					} else {
						this.getView().byId("employeeLocation").setValueState("Error");
						this.getView().byId("employeeLocation").setValueStateText("Please Enter Location");
						// isValid = false;
					}

				} else if (ID === "employeeDepartment") {
					var textName = this.getView().byId("employeeDepartmentTextEdit");

					if (nameValue !== "") {

						// this.getView().byId("employeeDepartment").setValueState("None");
						for (var i = 0; i < DepartMentEntity.length; i++) {

							if (DepartMentEntity[i].text === nameValue.trim()) {
								this.getView().byId("employeeDepartment").setValueState("None");
								// isValidComboboxDepartment=true;
								textName.setText(nameValue.trim());
								break;
							} else {
								this.getView().byId("employeeDepartment").setValueState("Error");
								this.getView().byId("employeeDepartment").setValueStateText("Please select correct Department");
								// isValidComboboxDepartment=false;
							}
						}

					} else {

						this.getView().byId("employeeDepartment").setValueState("Error");
						this.getView().byId("employeeDepartment").setValueStateText("Please Enter Valid Department");
						// isValid = false;
					}

				} else if (ID === "employeeID") {
					var textName = this.getView().byId("employeeidTextEdit");
					// var id=			this.getView().byId("employeeID").getValue();
					var ids = Number(nameValue);
					// var validID=/^[1-9]{1,4}$/;
					var idEmployee = nameValue.trim();
					if (idEmployee.match(validID)) {
						this.getView().byId("employeeID").setValueState("None");
						textName.setText(nameValue.trim());

					} else {
						if(nameValue===""||idEmployee.match(validID))
						{
												this.getView().byId("employeeID").setValueState("None");
		textName.setText(nameValue.trim());
						}
						else{
								this.getView().byId("employeeID").setValueState("Error");
						this.getView().byId("employeeID").setValueStateText("Please enter valid employeeID");
						}
						// this.getView().byId("employeeID").setValueState("Error");
						// this.getView().byId("employeeID").setValueStateText("Please enter valid employeeID");
						// isValid = false;
					}

				} else if (ID === "employeeMail") {

					var textMail = this.getView().byId("employeeMailTextEdit");
					if (nameValue.trim().match(validmail)) {
						this.getView().byId("employeeMail").setValueState("None");
						textMail.setText(nameValue.trim());

					} else {
						this.getView().byId("employeeMail").setValueState("Error");
						this.getView().byId("employeeMail").setValueStateText("Please Enter Mail");
						// isValid = false;
					}

				} else if (ID === "employeePhone") {

					var textMobile = this.getView().byId("employeePhone-noTextEdit");
					if (nameValue.trim().match(validateMobileNo)) {
						this.getView().byId("employeePhone").setValueState("None");
						textMobile.setText(nameValue.trim());

					} else {
						this.getView().byId("employeePhone").setValueState("Error");
						this.getView().byId("employeePhone").setValueStateText("Please Enter Mobile no");
						// isValid = false;
					}

				}
			
				else if (ID === "joiningDate") {

					var textjoiningDate = this.getView().byId("joiningDateTextEdit");
					var joinDate = new Date(nameValue);
					var Datecreate = DateFormat.getDateInstance({
						pattern: "dd.MM.yyyy"
					});

					var joinDate = Datecreate.format(joinDate);

					textjoiningDate.setText(joinDate);
					// CreatedByTextEdit employeeDepartmentTextEdit
				} else if (ID === "Status") {

					var textStatus = this.getView().byId("StatusTextEdit");
					if (nameValue !== "") {
						var statusEntity = model.getData().StatusText;

						for (var i = 0; i < statusEntity.length; i++) {

							if (statusEntity[i].text === nameValue.trim()) {
								this.getView().byId("Status").setValueState("None");
								// isValidCombobox=true;
								if (status === "In Progress") {
									var statusText = status.split(" ")[1].slice(0, 1);

								} else {
									var statusText = status.slice(0, 1);

								}
								textStatus.setText(nameValue.trim());

								break;
							} else {
								this.getView().byId("Status").setValueState("Error");
								this.getView().byId("Status").setValueStateText("Please select correct value");
								// isValidCombobox=false;
							}

						}
					} else {
						// isValid = false;

						this.getView().byId("Status").setValueState("Error");
						this.getView().byId("Status").setValueStateText("Please select correct value");

					}

				}
			}
		},
		SubmitEmployeeDetails: function()

		{
			debugger;
		  					   //var	   Status=      this.getView().byId("Status").getValue();
			var model = this.getView().getModel("StatusModel");

			var statusEntity = model.getData().StatusText;
			var LocationEntity = model.getData().LocationEntity;

			var DepartMentEntity = model.getData().Department;
			var Name = this.getView().byId("employeeName").getValue();
			var Department = this.getView().byId("employeeDepartment").getValue();
			var employeeDepartmentKey = this.getView().byId("employeeDepartment").getSelectedKey();

			var Mail = this.getView().byId("employeeMail").getValue();
			var Phone = this.getView().byId("employeePhone").getValue();
			var Location = this.getView().byId("employeeLocation").getValue();
			var locationKey = this.getView().byId("employeeLocation").getSelectedKey();
			var joiningDate = this.getView().byId("joiningDate").getValue();
			var createdDate = this.getView().byId("createDate").getValue();
			var createdTime = this.getView().byId("createTime").getValue();
			var status = this.getView().byId("Status").getValue();
		 var CreatedBy=	this.getView().byId("CreatedBy").getValue();

			// for(var i=0;i<=)
			var createddate = new Date();
			var datecreate = createddate.toISOString();
			var currentDate = datecreate.substring(0, 22);
			var dateandTime = createddate.toLocaleString();
			var onlytime = dateandTime.split(",").pop();

			var time = onlytime.split(":");

			// s=onlytime.split(":");

			var hours = time[0];

			var minutess = time[1];

			var seconds = time[2].split(" ")[0];

			var totalMilliseconds = (Number(hours) * 3600 + Number(minutess) * 60 + Number(seconds)) * 1000;

			var totalSeconds = Math.floor(totalMilliseconds / 1000);
			hours = Math.floor(totalSeconds / 3600);
			var minutes = Math.floor((totalSeconds % 3600) / 60);
			seconds = totalSeconds % 60;

			// var ss= `PT${hours}H${minutes}M${seconds}S`; 
			var Timeformat = 'PT' + hours + 'H' + minutes + 'M' + seconds + 'S';
			var validName = /^[a-zA-Z]+(?:\s[a-zA-Z]+)?$/;
			// var validID=/^[a-zA-Z0-9]{10}$/;

			var validateMobileNo = /^[89]\d{9}$/;
			var validmail = /^\w+([\.-]?\w+)@\w+([\.-]?\w+)(\.\w{2,3})+$/;

			var isValid = true;
			if (Name.trim().match(validName)) {
				this.getView().byId("employeeName").setValueState("None");
			} else {
				this.getView().byId("employeeName").setValueState("Error");
				this.getView().byId("employeeName").setValueStateText("Please Enter Name");
				isValid = false;
			}
			var isValidComboboxDepartment = true;
			if (Department !== "") {

				// this.getView().byId("employeeDepartment").setValueState("None");
				for (var i = 0; i < DepartMentEntity.length; i++) {

					if (DepartMentEntity[i].text.trim() === Department) {
						this.getView().byId("employeeDepartment").setValueState("None");
						isValidComboboxDepartment = true;

						break;
					} else {
						this.getView().byId("employeeDepartment").setValueState("Error");
						this.getView().byId("employeeDepartment").setValueStateText("Please select correct Department");
						isValidComboboxDepartment = false;
					}
				}

			} else {

				this.getView().byId("employeeDepartment").setValueState("Error");
				this.getView().byId("employeeDepartment").setValueStateText("Please Enter Valid Department");
				isValid = false;
			}
			if (Mail.trim().match(validmail)) {
				this.getView().byId("employeeMail").setValueState("None");

			} else {
				this.getView().byId("employeeMail").setValueState("Error");
				this.getView().byId("employeeMail").setValueStateText("Please Enter Mail");
				isValid = false;
			}
			if (Phone.trim().match(validateMobileNo)) {
				this.getView().byId("employeePhone").setValueState("None");

			} else {
				this.getView().byId("employeePhone").setValueState("Error");
				this.getView().byId("employeePhone").setValueStateText("Please Enter Mobile no");
				isValid = false;
			}
			var isValidComboboxLocation = true;

			if (Location !== "") {
				// this.getView().byId("employeeLocation").setValueState("None");

				for (var i = 0; i < LocationEntity.length; i++) {

					if (LocationEntity[i].text.trim() === Location) {
						this.getView().byId("employeeLocation").setValueState("None");
						isValidComboboxLocation = true;

						break;
					} else {
						this.getView().byId("employeeLocation").setValueState("Error");
						this.getView().byId("employeeLocation").setValueStateText("Please select correct value");
						isValidComboboxLocation = false;
					}
				}
			} else {
				this.getView().byId("employeeLocation").setValueState("Error");
				this.getView().byId("employeeLocation").setValueStateText("Please Enter Location");
				isValid = false;
			}
			var isValidCombobox = true;
			if (status !== "") {
				for (var i = 0; i < statusEntity.length; i++) {

					if (statusEntity[i].text.trim() === status) {
						this.getView().byId("Status").setValueState("None");
						isValidCombobox = true;
						if (status === "In Progress") {
							var statusText = status.split(" ")[1].slice(0, 1);

						} else {
							var statusText = status.slice(0, 1);

						}

						break;
					} else {
						this.getView().byId("Status").setValueState("Error");
						this.getView().byId("Status").setValueStateText("Please select correct value");
						isValidCombobox = false;
					}

				}
			} else {
				isValid = false;

				this.getView().byId("Status").setValueState("Error");
				this.getView().byId("Status").setValueStateText("Please select correct value");

			}

			if (joiningDate !== "") {
				this.getView().byId("joiningDate").setValueState("None");
				this.joinDate = new Date(joiningDate);
			
				var datejion = new Date(this.joinDate);
				var DatecreateEditFormat = DateFormat.getDateInstance({
					pattern: "YYYY-MM-ddT00:00:00"
				});

				var JoinDate = DatecreateEditFormat.format(datejion);

			} else {
				this.getView().byId("joiningDate").setValueState("Error");
				this.getView().byId("joiningDate").setValueStateText("Please enter joining Date");
				isValid = false;
			}
			var id = this.getView().byId("employeeID").getValue();
			var ids = Number(id);
			var validID = /^[0-9]{1,4}$/;
			var idEmployee = id.trim();
			if (idEmployee.match(validID)) {
				this.getView().byId("employeeID").setValueState("None");

			} else {
				this.getView().byId("employeeID").setValueState("Error");
				this.getView().byId("employeeID").setValueStateText("Please enter valid employeeID");
				isValid = false;
			}
			if (isValid && isValidCombobox === true && isValidComboboxLocation === true && isValidComboboxDepartment === true) {

			
				// this.getView().byId("employeeID").setValue();
				this.payload = {
					"Emp_Id": id,
					"Emp_Name": Name.toUpperCase(),
					"Emp_Dept": Department.toUpperCase(),
					"Emp_Mail": Mail,
					"Emp_PhnNo": Phone,
					"Emp_Loc": Location.toUpperCase(),
					"Emply_JDate": JoinDate,
					"CreatedDate": currentDate,
					"CreatedTime": Timeformat,
					"Status": statusText,
					"Created_by": CreatedBy.toUpperCase()

				};
			if(this.getView().byId("employeeID").getEditable()===false)
			{
				
				this.modelupdateing();	
			}
			else{
				
					this.modelcrearing();
				
			}
			} else {

				MessageBox.error("Please Check All Fields");
			}
		},
		OnBack: function() {
			debugger;
			// var searchfield = this.getView().byId("searchField");
			// that.getView().byId("searchField").setVisible(false);
			this.getView().byId("employeeID").getValue();
		
			var that = this;
			if (this.getView().byId("employeeName").getValue() === "" &&
				this.getView().byId("employeeDepartment").getValue() === "" && this.getView().byId("employeeMail").getValue() === "" &&
				this.getView().byId("employeePhone").getValue() === "" && this.getView().byId("employeeLocation").getValue() === "" &&
				this.getView().byId("joiningDate").getValue() === "" || this.getView().byId("simpleform").getVisible() === false) {
				this.TableTotal();
				this.getView().byId("title").setVisible(true);

				this.inputValueState();
				this.getView().byId("BackBtn").setVisible(false);
				this.getView().byId("searchField").setVisible(true);
			} else {

				MessageBox.confirm("Are you sure want to navigate Back data will be lost", {
					onClose: function(Navgiate) {
						if (Navgiate === "OK") {

							// MessageBox.success("Deleted ");
							that.TableTotal();
							that.getView().byId("title").setVisible(true);
							that.getView().byId("BackBtn").setVisible(false);
							that.getView().byId("searchField").setVisible(true);
							that.inputValueState();
							that.getView().byId("employeeName").setValue("");
							that.getView().byId("employeeDepartment").setValue("");
							that.getView().byId("employeeMail").setValue("");
							that.getView().byId("employeePhone").setValue("");
							that.getView().byId("employeeLocation").setValue("");
							that.getView().byId("joiningDate").setValue("");
						}

					}

				});

			}
		},
		TableTotal: function() {
			var oTable = this.getView().byId("myTable");

			var aColumns = oTable.getColumns();

			for (var i = 2; i < aColumns.length; i++) {
				aColumns[i].setVisible(true);

			}
			oTable.setWidth("100%");

			this.getView().byId("simpleform").setVisible(false);
			this.getView().byId("simpleformText").setVisible(false);

		},
		onRowclicking: function() {
	
			var that = this;
			this.getView().byId("CompanyNameLabel").setVisible(true);
			this.getView().byId("CompanyLocationLabel").setVisible(true);
			this.getView().byId("companyMailLabel").setVisible(true);
			this.getView().byId("CompanyUrlLabel").setVisible(true);
			this.getView().byId("ContactNoLabel").setVisible(true);

			this.getView().byId("CompanyMailText").setVisible(true);
			this.getView().byId("CompanyUrl").setVisible(true);
			this.getView().byId("companyNameText").setVisible(true);
			this.getView().byId("CompanyLocationText").setVisible(true);
			this.getView().byId("ContactNoText").setVisible(true);

			this.getView().byId("empIDLabel").setVisible(true);
			this.getView().byId("empNameLabel").setVisible(false);
			this.getView().byId("empDepartmentLabel").setVisible(false);
			this.getView().byId("empMailLabel").setVisible(false);
			this.getView().byId("empMobilelabel").setVisible(false);
			this.getView().byId("emploclabel").setVisible(false);
			this.getView().byId("empjoinlabel").setVisible(false);
			this.getView().byId("empstatusLabel").setVisible(false);
			this.getView().byId("empcreatedLabel").setVisible(false);

			// 
			this.getView().byId("employeeidTextEdit").setVisible(true);
			this.getView().byId("employeeNameTextEdit").setVisible(false);
			this.getView().byId("employeeDepartmentTextEdit").setVisible(false);
			this.getView().byId("employeeMailTextEdit").setVisible(false);
			this.getView().byId("employeePhone-noTextEdit").setVisible(false);
			this.getView().byId("employeeLocationTextEdit").setVisible(false);
			this.getView().byId("joiningDateTextEdit").setVisible(false);
			this.getView().byId("StatusTextEdit").setVisible(false);

			this.getView().byId("CreatedByTextEdit").setVisible(false);

			// that.getView().byId("employeeidTextEdit").setText(company.Emp_Id);
			this.getView().byId("companyNameText").setText(that.company.CompanyName);

			this.getView().byId("CompanyLocationText").setText(that.company.CompanyLoc);
			this.getView().byId("ContactNoText").setText(that.company.ContactNo);
			this.getView().byId("CompanyMailText").setText(that.company.CompanyMail);
			// that.getView().byId("employeePhone-noText").setText();
			// that.getView().byId("CompanyUrlEdit").setText(company.CompanyUrl);
			this.getView().byId("CompanyUrl").setText(that.company.CompanyUrl);
			that.getView().byId("employeeidTextEdit").setText(this.objRowclicked.Emp_Id);

		
			this.getView().byId("simpleform").setVisible(false);
			this.getView().byId("simpleformText").setVisible(true);

		},
		oncreating: function() {

		
			var that = this;
			this.getView().byId("simpleform").setVisible(true);
			this.getView().byId("simpleformText").setVisible(true);
			this.getView().byId("CompanyNameLabel").setVisible(false);
			this.getView().byId("CompanyLocationLabel").setVisible(false);
			this.getView().byId("companyMailLabel").setVisible(false);
			this.getView().byId("CompanyUrlLabel").setVisible(false);
			this.getView().byId("ContactNoLabel").setVisible(false);

			this.getView().byId("CompanyMailText").setVisible(false);
			this.getView().byId("CompanyUrl").setVisible(false);
			this.getView().byId("companyNameText").setVisible(false);
			this.getView().byId("CompanyLocationText").setVisible(false);
			this.getView().byId("ContactNoText").setVisible(false);

			this.getView().byId("employeeID").setValue("");
			this.getView().byId("employeeName").setValue("");
			this.getView().byId("employeeDepartment").setValue("");
			this.getView().byId("employeeMail").setValue("");
			this.getView().byId("employeePhone").setValue("");
			this.getView().byId("employeeLocation").setValue("");
			this.getView().byId("joiningDate").setValue("");
			this.getView().byId("Status").setValue("");
			//this.getView().byId("CreatedBy").setVisible(true);
			this.getView().byId("CreatedBy").setValue("");

			this.getView().byId("employeeidTextEdit").setText("");
			this.getView().byId("employeeNameTextEdit").setText("");
			this.getView().byId("employeeDepartmentTextEdit").setText("");
			this.getView().byId("employeeMailTextEdit").setText("");
			this.getView().byId("employeePhone-noTextEdit").setText("");
			this.getView().byId("employeeLocationTextEdit").setText("");
			this.getView().byId("joiningDateTextEdit").setText("");
			this.getView().byId("StatusTextEdit").setText("");
			this.getView().byId("CreatedByTextEdit").setText("");

			//
			//this.getView().byId("CreatedBy").setValue("");

			this.getView().byId("employeeidTextEdit").setVisible(true);
			this.getView().byId("employeeNameTextEdit").setVisible(true);
			this.getView().byId("employeeDepartmentTextEdit").setVisible(true);
			this.getView().byId("employeeMailTextEdit").setVisible(true);
			this.getView().byId("employeePhone-noTextEdit").setVisible(true);
			this.getView().byId("employeeLocationTextEdit").setVisible(true);
			this.getView().byId("joiningDateTextEdit").setVisible(true);
			this.getView().byId("StatusTextEdit").setVisible(true);
			this.getView().byId("CreatedByTextEdit").setVisible(false);
			//
			this.getView().byId("empIDLabel").setVisible(true);
			this.getView().byId("empNameLabel").setVisible(true);
			this.getView().byId("empDepartmentLabel").setVisible(true);
			this.getView().byId("empMailLabel").setVisible(true);
			this.getView().byId("empMobilelabel").setVisible(true);
			this.getView().byId("emploclabel").setVisible(true);
			this.getView().byId("empjoinlabel").setVisible(true);
			this.getView().byId("empstatusLabel").setVisible(true);
			this.getView().byId("empcreatedLabel").setVisible(true);
		},
		onTableSearch: function(oEvent) {
			debugger;
			var value = oEvent.getParameter("query");

			// var model = this.getView().getModel("newServiceEmployeeModel");
			var Table = this.getView().byId("myTable");
			var tableData = Table.getBinding("items");

			var filter = new Filter([
				new Filter("Emp_Id", FilterOperator.Contains, value.trim()),
				//         new	Filter("Emp_Name",FilterOperator.Contains,value),
				// new			Filter("Status",FilterOperator.Contains,value)

			], false);
			tableData.filter(filter);

		},
		onDeleteRow: function(oevent) {
			var idrowdelete = oevent.getSource().getBindingContext("ODataEmployeeEntity").getPath();

			var table = this.getView().byId("myTable");
			var that = this;
			// if (table.length >= 1) {
			// 	var path = table[0].getBindingContext("newServiceEmployeeModel").getPath();
			var model = this.getView().getModel("ODataEmployeeEntity");
			MessageBox.confirm("Are you sure want to Delete", {
				onClose: function(deleterecord) {
						if (deleterecord === MessageBox.Action.OK) {
							model.remove(idrowdelete, {
								success: function() {
									MessageBox.success("Deleted ");

								},
								error: function(error) {
									MessageBox.error(error);
								}
							});
							
						}

					}
				
			});
		},
		inputValueState: function() {
			this.getView().byId("employeeID").setValueState("None");
			this.getView().byId("employeeName").setValueState("None");
			this.getView().byId("employeeDepartment").setValueState("None");
			this.getView().byId("employeeMail").setValueState("None");
			this.getView().byId("employeePhone").setValueState("None");
			this.getView().byId("employeeLocation").setValueState("None");
			this.getView().byId("joiningDate").setValueState("None");
			this.getView().byId("Status").setValueState("None");
			//this.getView().byId("CreatedBy").setVisible(true);
			this.getView().byId("CreatedBy").setValueState("None");

		},
		modelcrearing:function(){
			debugger;
			var isduplicate=false;
				var that = this;
var table=this.getView().byId("myTable").getItems().length;
				var model = this.getView().getModel("ODataEmployeeEntity");


for(var i=0;i<=table-1;i++)
{                                 var items=	this.getView().byId("myTable").getItems();
				var idText=	items[i].getCells()[0].getText();

	if(this.payload.Emp_Id===idText)
	{
		// MessageBox.warning("DuplicateId");
		isduplicate=true;
		break;
	}
	else{
		isduplicate=false;
	}
	
}
if(isduplicate===false)
{
				model.create("/zemployeeSet", this.payload, {
					success: function(oData) {
						
						// if(that.getView().byId("employeeID").getEditable()===true)
						// {
											
		MessageBox.success("Data created Successful");
		// 				}
		// 				else{
											
		// MessageBox.success("Data Updated Successful");
		// 				}
						that.getView().byId("employeeID").setValue("");
						that.getView().byId("employeeName").setValue("");
						that.getView().byId("employeeDepartment").setValue("");
						that.getView().byId("employeeMail").setValue("");
						that.getView().byId("employeePhone").setValue("");
						that.getView().byId("employeeLocation").setValue("");
						that.getView().byId("joiningDate").setValue("");
						that.getView().byId("createDate").setValue("");
						that.getView().byId("createTime").setValue("");
						that.getView().byId("CreatedBy").setValue("");
						that.getView().byId("Status").setSelectedKey(null);
						var datejion = new Date(that.joinDate);
						var DatecreateEditFormat = DateFormat.getDateInstance({
							pattern: "dd.MM.yyyy"
						});

						var JoinDateFormat = DatecreateEditFormat.format(datejion);
						// employeeName
						that.getView().byId("employeeidTextEdit").setText(that.payload.Emp_Id);
						that.getView().byId("employeeNameTextEdit").setText(that.payload.Emp_Name);
						that.getView().byId("employeeDepartmentTextEdit").setText(that.payload.Emp_Dept);
						that.getView().byId("employeeMailTextEdit").setText(that.payload.Emp_Mail);
						that.getView().byId("employeePhone-noTextEdit").setText(that.payload.Emp_PhnNo);
						that.getView().byId("employeeLocationTextEdit").setText(that.payload.Emp_Loc);
						that.getView().byId("joiningDateTextEdit").setText(JoinDateFormat);
						//that.getView().byId("StatusTextEdit").setText(payload.Status);
						that.getView().byId("simpleform").setVisible(false);
						if (that.payload.Status === "A")

						{
							that.getView().byId("StatusTextEdit").setText("Approved");
							//this.getView().byId("Status").setValue("Approved");

						} else if (that.payload.Status === "R") {
							that.getView().byId("StatusTextEdit").setText("Reject");
							//this.getView().byId("Status").setValue("Reject");

						} else if (that.payload.Status === "P") {

							that.getView().byId("StatusTextEdit").setText("In Progress");
							//this.getView().byId("Status").setValue("Pending");

						}

					
					},
					error: function(error) {
							// MessageBox.error(error.response.statusText);
						}
						// });
				});
}
else{
	MessageBox.warning("Duplicate Id");
}
		},
			modelupdateing:function(){
				var that = this;

				var model = this.getView().getModel("ODataEmployeeEntity");

				model.update(this.path, this.payload, {
					success: function(oData) {
						
						// if(that.getView().byId("employeeID").getEditable()===true)
						// {
											
		// MessageBox.success("Data  Successful");
		// 				}
		// 				else{
											
		MessageBox.success("Data Updated Successful");
		// 				}
						that.getView().byId("employeeID").setValue("");
						that.getView().byId("employeeName").setValue("");
						that.getView().byId("employeeDepartment").setValue("");
						that.getView().byId("employeeMail").setValue("");
						that.getView().byId("employeePhone").setValue("");
						that.getView().byId("employeeLocation").setValue("");
						that.getView().byId("joiningDate").setValue("");
						that.getView().byId("createDate").setValue("");
						that.getView().byId("createTime").setValue("");
						that.getView().byId("CreatedBy").setValue("");
						that.getView().byId("Status").setSelectedKey(null);
						var datejion = new Date(that.joinDate);
						var DatecreateEditFormat = DateFormat.getDateInstance({
							pattern: "dd.MM.yyyy"
						});

						var JoinDateFormat = DatecreateEditFormat.format(datejion);
						// employeeName
						that.getView().byId("employeeidTextEdit").setText(that.payload.Emp_Id);
						that.getView().byId("employeeNameTextEdit").setText(that.payload.Emp_Name);
						that.getView().byId("employeeDepartmentTextEdit").setText(that.payload.Emp_Dept);
						that.getView().byId("employeeMailTextEdit").setText(that.payload.Emp_Mail);
						that.getView().byId("employeePhone-noTextEdit").setText(that.payload.Emp_PhnNo);
						that.getView().byId("employeeLocationTextEdit").setText(that.payload.Emp_Loc);
						that.getView().byId("joiningDateTextEdit").setText(JoinDateFormat);
						//that.getView().byId("StatusTextEdit").setText(payload.Status);
						that.getView().byId("simpleform").setVisible(false);
						if (that.payload.Status === "A")

						{
							that.getView().byId("StatusTextEdit").setText("Approved");
							//this.getView().byId("Status").setValue("Approved");

						} else if (that.payload.Status === "R") {
							that.getView().byId("StatusTextEdit").setText("Reject");
							//this.getView().byId("Status").setValue("Reject");

						} else if (that.payload.Status === "P") {

							that.getView().byId("StatusTextEdit").setText("In Progress");
							//this.getView().byId("Status").setValue("Pending");

						}

					
					},
					error: function(error) {
							// MessageBox.error(error.response.statusText);
						}
						// });
				});
		}

	});
});