sap.ui.define([], function () {
  "use strict";

  return {
    /**
     * Returns a CSS class based on the status.
     * @param {string} Status - The status to check.
     * @returns {string} - The CSS class name.
     */
    getRatingClass: function(Status) {
    
     
     
      if (Status === "A") {
        return "Success";
      
        
      }
      else if(Status==="P")
      {
              return "Warning";
	
      }
       else if(Status==="R")
      {
              return "Error";
	
      }
     
     
     
    },
    getRatingText:function(Status)
    {
     if (Status === "A") {
        return "Approved";
        
      
        
      }	
       else if(Status==="P")
      {
              return "In Progress";
	
      }
       else if(Status==="R")
      {
              return "Reject";
	
      }
    }
    
  };
});